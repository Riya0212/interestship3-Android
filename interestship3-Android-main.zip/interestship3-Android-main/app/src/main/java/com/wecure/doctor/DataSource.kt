package com.wecure.doctor

class DataSource{

    companion object{

        fun createDataSet(): ArrayList<DoctorModel>{
            val list = ArrayList<DoctorModel>()
            list.add(
                DoctorModel(
                    "1-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "2-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "3-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "4-Hrishita",
                    "orthopedic surgeon",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "5- Hrishita",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "6- Hrishita",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "7- Hrishita",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "8-Hrishita",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "8- Hrishita",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "9-Hrishita",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "10-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "11- Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "12-Hrishita",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "13-Hrishita",
                    "orthopedic",
                    R.drawable.download
                )
            )
            list.add(
                DoctorModel(
                    "14-Hrishita",
                    "orthopedic",
                    R.drawable.download
                )
            )
            return list
        }


        fun createDataSetHistory(): ArrayList<HistoryModel>{
            val listHistory = ArrayList<HistoryModel>()
            listHistory.add(
                HistoryModel(
                    "1-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "2-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "3-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "4-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "5-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "6-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "7-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "8-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "9-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "10-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "11-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "12-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "13-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )
            listHistory.add(
                HistoryModel(
                    "14-Hrishita Mavani",
                    "orthopedic",
                    R.drawable.download,
                    "10-05-200"
                )

            )

            return listHistory
        }

    }
}