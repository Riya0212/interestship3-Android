package com.wecure.doctor


data class DoctorModel(val name:String, val desc:String, val image: Int)