package com.wecure.doctor

data class HistoryModel(val name:String, val category:String, val image: Int,val date:String)