package com.wecure.doctor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class HistoryRecyclerView : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_recycler_view)
    }
}